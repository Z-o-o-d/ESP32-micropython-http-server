from .response import Response
from .request import Request


class Session():
    def init(self, resquets: Request, response: Response):
        pass

    def close(self):
        pass
